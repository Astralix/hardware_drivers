function DwPhyLab_SetDwPhyEnableFn
% Provide DwPhy with a pointer to a function to control DW_PHYEnB

% Written by Barrett Brickner
% Copyright 2008 DSP Group, Inc., All Rights Reserved.

DwPhyMex('DwPhy_SetDwPhyEnableFn');


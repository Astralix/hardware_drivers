function DwPhyLab_WriteRegister(ParameterName, Value)
% Write a PHY register or register field
%
%    DwPhyLab_WriteRegister(ParameterName, Value) writes the Value to the specified
%    register field described by ParameterName. The name-lookup is baseband-specific.

% Written by Barrett Brickner
% Copyright 2010 DSP Group, Inc., All Rights Reserved.

wise_WriteRegisterCore(@ReadWriteFn, ParameterName, Value);

%% ReadWriteFn
function Data = ReadWriteFn(Address, Value)
if nargin == 1,
    Data = DwPhyMex('OS_RegRead',Address);
else
    DwPhyMex('OS_RegWrite',Address,Value);
end


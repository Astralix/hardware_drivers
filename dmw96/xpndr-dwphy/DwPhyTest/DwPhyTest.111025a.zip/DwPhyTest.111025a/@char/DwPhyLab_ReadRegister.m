function Value = DwPhyLab_ReadRegister(ParameterName)
% Read a PHY register or register field
%
%    Data = DwPhyLab_ReadRegister(ParameterName) returns the value of the specified
%    parameter. The parameter name lookup is baseband specific.

% Written by Barrett Brickner
% Copyright 2010 DSP Group, Inc., All Rights Reserved.

Value = wise_ReadRegisterCore(@ReadFn, ParameterName);

%% ReadFn
function Value = ReadFn(Address)
Value = DwPhyMex('OS_RegRead',Address);
